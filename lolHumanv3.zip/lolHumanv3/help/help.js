const help = (prefix) => {
    return `*◪* *Informasi BOT*
*│◪* *Ver : Termux*
*│◪* *Prefix : 「 ${prefix} 」*
*│◪* *Host : Phone*
*└◪› UCING-BOT*
│
⎮彡${prefix}help
⎮彡${prefix}donate
⎮彡${prefix}sticker
⎮彡${prefix}stickerwm
⎮彡${prefix}broadcast
⎮彡${prefix}hidetag
⎮彡${prefix}tagstick
⎮彡${prefix}clearall
│
└◪「 Islami 」
⎮彡${prefix}listsurah
⎮彡${prefix}asmaulhusna
⎮彡${prefix}alquran no_surah
⎮彡${prefix}alquran no_surah/no_ayat
⎮彡${prefix}alquran no_surah/no_ayat1-no_ayat2
⎮彡${prefix}alquranaudio no_surah
⎮彡${prefix}alquranaudio no_surah/no_ayat
⎮彡${prefix}kisahnabi nama_nabi
⎮彡${prefix}jadwalsholat daerah
│
└◪「 Downloader 」
⎮彡${prefix}ytsearch query
⎮彡${prefix}ytplay query
⎮彡${prefix}ytplay2 query
⎮彡${prefix}ytmp3 url_video
⎮彡${prefix}ytmp32 url_video
⎮彡${prefix}ytmp4 url_video
⎮彡${prefix}ytmp42 url_video
⎮彡${prefix}tiktoknowm url_video
⎮彡${prefix}tiktokmusic url_video
⎮彡${prefix}igdl url_post
⎮彡${prefix}fbdl url_video
⎮彡${prefix}jooxplay query
⎮彡${prefix}spotify url_music
⎮彡${prefix}spotifysearch query
⎮彡${prefix}pinterest query
⎮彡${prefix}pinterestdl url_pinterest
⎮彡${prefix}pixiv query
⎮彡${prefix}pixivdl url_pixiv
⎮彡${prefix}zippyshare url_zippyshare
⎮彡${prefix}telesticker url_pack
│
└◪「 Movie & Story 」
⎮彡${prefix}drakorongoing
⎮彡${prefix}lk21 query
⎮彡${prefix}wattpad url_wattpad
⎮彡${prefix}wattpadsearch query
⎮彡${prefix}cerpen
⎮彡${prefix}ceritahoror
│
└◪「 Searching 」
⎮彡${prefix}shopee query
⎮彡${prefix}google query
⎮彡${prefix}gimage query
⎮彡${prefix}gimage2 query
⎮彡${prefix}konachan query
⎮彡${prefix}playstore query
⎮彡${prefix}stickerwa query
⎮彡${prefix}wallpapersearch query
⎮彡${prefix}wallpapersearch2 query
│
└◪「 Random Text 」
⎮彡${prefix}quotes
⎮彡${prefix}quotesdilan
⎮彡${prefix}quotesanime
⎮彡${prefix}quotesimage
⎮彡${prefix}faktaunik
⎮彡${prefix}katabijak
⎮彡${prefix}pantun
⎮彡${prefix}bucin
⎮彡${prefix}randomnama
│
└◪「 AniManga 」
⎮彡${prefix}wait
⎮彡${prefix}manga query
⎮彡${prefix}anime query
⎮彡${prefix}character query
⎮彡${prefix}kusonime url_kusonime
⎮彡${prefix}kusonimesearch query
⎮彡${prefix}otakudesu url_otakudesu
⎮彡${prefix}otakudesusearch query
⎮彡${prefix}nhentai kode_bom
⎮彡${prefix}nhentaipdf kode_bom
⎮彡${prefix}nhentaisearch query
⎮彡${prefix}nekopoi url
⎮彡${prefix}nekopoisearch query
│
└◪「 Information 」
⎮彡${prefix}jadwaltv channel
⎮彡${prefix}jadwaltvnow
⎮彡${prefix}jadwalbola
⎮彡${prefix}qrreader
⎮彡${prefix}heroml hero_name
⎮彡${prefix}mlstalk id/server
⎮彡${prefix}genshin character
⎮彡${prefix}wikipedia query
⎮彡${prefix}translate kode_negara text
⎮彡${prefix}brainly query
⎮彡${prefix}newsinfo
⎮彡${prefix}cnnindonesia
⎮彡${prefix}cnnnasional
⎮彡${prefix}cnninternasional
⎮彡${prefix}infogempa
⎮彡${prefix}lirik query
⎮彡${prefix}cuaca daerah
⎮彡${prefix}kodepos query
⎮彡${prefix}indbeasiswa
⎮彡${prefix}hoax
⎮彡${prefix}nsfwcheck
⎮彡${prefix}ocr
│
└◪「 Entertainment 」
⎮彡${prefix}asupan
⎮彡${prefix}wancak
⎮彡${prefix}tebakgambar
⎮彡${prefix}canceltebakgambar
⎮彡${prefix}akinator
⎮彡${prefix}cancelakinator
│
└◪「 Creator 」
⎮彡${prefix}ttp text
⎮彡${prefix}ttp2 text
⎮彡${prefix}ttp3 text
⎮彡${prefix}ttp4 text
⎮彡${prefix}attp text
⎮彡${prefix}smoji emoji
⎮彡${prefix}fakedonald text
⎮彡${prefix}ktpmaker
│
└◪「 Primbon 」
⎮彡${prefix}artinama name
⎮彡${prefix}jodoh name1 & name2 
⎮彡${prefix}weton tanggal bulan tahun
⎮彡${prefix}jadian tanggal bulan tahun
⎮彡${prefix}tebakumur name
│
└◪「 Other 」
⎮彡${prefix}ssweb link
⎮彡${prefix}ssweb2 link
⎮彡${prefix}shortlink link
⎮彡${prefix}spamsms nomor
│
└◪「 Text Pro Me 」
⎮彡${prefix}blackpink text
⎮彡${prefix}neon text
⎮彡${prefix}greenneon text
⎮彡${prefix}advanceglow text
⎮彡${prefix}futureneon text
⎮彡${prefix}sandwriting text
⎮彡${prefix}sandsummer text
⎮彡${prefix}sandengraved text
⎮彡${prefix}metaldark text
⎮彡${prefix}neonlight text
⎮彡${prefix}holographic text
⎮彡${prefix}text1917 text
⎮彡${prefix}minion text
⎮彡${prefix}deluxesilver text
⎮彡${prefix}newyearcard text
⎮彡${prefix}bloodfrosted text
⎮彡${prefix}halloween text
⎮彡${prefix}jokerlogo text
⎮彡${prefix}fireworksparkle text
⎮彡${prefix}natureleaves text
⎮彡${prefix}bokeh text
⎮彡${prefix}toxic text
⎮彡${prefix}strawberry text
⎮彡${prefix}box3d text
⎮彡${prefix}roadwarning text
⎮彡${prefix}breakwall text
⎮彡${prefix}icecold text
⎮彡${prefix}luxury text
⎮彡${prefix}cloud text
⎮彡${prefix}summersand text
⎮彡${prefix}horrorblood text
⎮彡${prefix}thunder text
⎮彡${prefix}pornhub text1 text2
⎮彡${prefix}glitch text1 text2
⎮彡${prefix}avenger text1 text2
⎮彡${prefix}space text1 text2
⎮彡${prefix}ninjalogo text1 text2
⎮彡${prefix}marvelstudio text1 text2
⎮彡${prefix}lionlogo text1 text2
⎮彡${prefix}wolflogo text1 text2
⎮彡${prefix}steel3d text1 text2
⎮彡${prefix}wallgravity text1 text2
│
└◪「 Photo Oxy 」
⎮彡${prefix}shadow text
⎮彡${prefix}cup text
⎮彡${prefix}cup1 text
⎮彡${prefix}romance text
⎮彡${prefix}smoke text
⎮彡${prefix}burnpaper text
⎮彡${prefix}lovemessage text
⎮彡${prefix}undergrass text
⎮彡${prefix}love text
⎮彡${prefix}coffe text
⎮彡${prefix}woodheart text
⎮彡${prefix}woodenboard text
⎮彡${prefix}summer3d text
⎮彡${prefix}wolfmetal text
⎮彡${prefix}nature3d text
⎮彡${prefix}underwater text
⎮彡${prefix}golderrose text
⎮彡${prefix}summernature text
⎮彡${prefix}letterleaves text
⎮彡${prefix}glowingneon text
⎮彡${prefix}fallleaves text
⎮彡${prefix}flamming text
⎮彡${prefix}harrypotter text
⎮彡${prefix}carvedwood text
⎮彡${prefix}tiktok text1 text2
⎮彡${prefix}arcade8bit text1 text2
⎮彡${prefix}battlefield4 text1 text2
⎮彡${prefix}pubg text1 text2
│
└◪「 Ephoto 360 」
⎮彡${prefix}wetglass text
⎮彡${prefix}multicolor3d text
⎮彡${prefix}watercolor text
⎮彡${prefix}luxurygold text
⎮彡${prefix}galaxywallpaper text
⎮彡${prefix}lighttext text
⎮彡${prefix}beautifulflower text
⎮彡${prefix}puppycute text
⎮彡${prefix}royaltext text
⎮彡${prefix}heartshaped text
⎮彡${prefix}birthdaycake text
⎮彡${prefix}galaxystyle text
⎮彡${prefix}hologram3d text
⎮彡${prefix}greenneon text
⎮彡${prefix}glossychrome text
⎮彡${prefix}greenbush text
⎮彡${prefix}metallogo text
⎮彡${prefix}noeltext text
⎮彡${prefix}glittergold text
⎮彡${prefix}textcake text
⎮彡${prefix}starsnight text
⎮彡${prefix}wooden3d text
⎮彡${prefix}textbyname text
⎮彡${prefix}writegalacy text
⎮彡${prefix}galaxybat text
⎮彡${prefix}snow3d text
⎮彡${prefix}birthdayday text
⎮彡${prefix}goldplaybutton text
⎮彡${prefix}silverplaybutton text
⎮彡${prefix}freefire text
│
└◪「 Random Image  」
⎮彡${prefix}art
⎮彡${prefix}bts
⎮彡${prefix}exo
⎮彡${prefix}elf
⎮彡${prefix}loli
⎮彡${prefix}neko
⎮彡${prefix}waifu
⎮彡${prefix}shota
⎮彡${prefix}husbu
⎮彡${prefix}sagiri
⎮彡${prefix}shinobu
⎮彡${prefix}megumin
⎮彡${prefix}wallnime
⎮彡${prefix}chiisaihentai
⎮彡${prefix}trap
⎮彡${prefix}blowjob
⎮彡${prefix}yaoi
⎮彡${prefix}ecchi
⎮彡${prefix}hentai
⎮彡${prefix}ahegao
⎮彡${prefix}hololewd
⎮彡${prefix}sideoppai
⎮彡${prefix}animefeets
⎮彡${prefix}animebooty
⎮彡${prefix}animethighss
⎮彡${prefix}hentaiparadise
⎮彡${prefix}animearmpits
⎮彡${prefix}hentaifemdom
⎮彡${prefix}lewdanimegirls
⎮彡${prefix}biganimetiddies
⎮彡${prefix}animebellybutton
⎮彡${prefix}hentai4everyone
⎮彡${prefix}bj
⎮彡${prefix}ero
⎮彡${prefix}cum
⎮彡${prefix}feet
⎮彡${prefix}yuri
⎮彡${prefix}trap
⎮彡${prefix}lewd
⎮彡${prefix}feed
⎮彡${prefix}eron
⎮彡${prefix}solo
⎮彡${prefix}gasm
⎮彡${prefix}poke
⎮彡${prefix}anal
⎮彡${prefix}holo
⎮彡${prefix}tits
⎮彡${prefix}kuni
⎮彡${prefix}kiss
⎮彡${prefix}erok
⎮彡${prefix}smug
⎮彡${prefix}baka
⎮彡${prefix}solog
⎮彡${prefix}feetg
⎮彡${prefix}lewdk
⎮彡${prefix}waifu
⎮彡${prefix}pussy
⎮彡${prefix}femdom
⎮彡${prefix}cuddle
⎮彡${prefix}hentai
⎮彡${prefix}eroyuri
⎮彡${prefix}cum_jpg
⎮彡${prefix}blowjob
⎮彡${prefix}erofeet
⎮彡${prefix}holoero
⎮彡${prefix}classic
⎮彡${prefix}erokemo
⎮彡${prefix}fox_girl
⎮彡${prefix}futanari
⎮彡${prefix}lewdkemo
⎮彡${prefix}wallpaper
⎮彡${prefix}pussy_jpg
⎮彡${prefix}kemonomimi
⎮彡${prefix}nsfw_avatar
⎮彡${prefix}ngif
⎮彡${prefix}nsfw_neko_gif
⎮彡${prefix}random_hentai_gif
│
❏ *THANKS TO*
*│CREDIT BY: LOLHUMAN*
*│Sansline*
*│lolhuman*
  └◪› UCING BOTZ`
}
exports.help = help

const donate = (sender) => {
    return `Isi punya situ ae ngabs`
}
exports.donate = donate


const bahasa = () => {
    return `
List Bahasa :
  af: Afrikaans
  sq: Albanian
  ar: Arabic
  hy: Armenian
  ca: Catalan
  zh: Chinese
  zh-cn: Chinese (Mandarin/China)
  zh-tw: Chinese (Mandarin/Taiwan)
  zh-yue: Chinese (Cantonese)
  hr: Croatian
  cs: Czech
  da: Danish
  nl: Dutch
  en: English
  en-au: English (Australia)
  en-uk: English (United Kingdom)
  en-us: English (United States)
  eo: Esperanto
  fi: Finnish
  fr: French
  de: German
  el: Greek
  ht: Haitian Creole
  hi: Hindi
  hu: Hungarian
  is: Icelandic
  id: Indonesian
  it: Italian
  ja: Japanese
  ko: Korean
  la: Latin
  lv: Latvian
  mk: Macedonian
  no: Norwegian
  pl: Polish
  pt: Portuguese
  pt-br: Portuguese (Brazil)
  ro: Romanian
  ru: Russian
  sr: Serbian
  sk: Slovak
  es: Spanish
  es-es: Spanish (Spain)
  es-us: Spanish (United States)
  sw: Swahili
  sv: Swedish
  ta: Tamil
  th: Thai
  tr: Turkish
  vi: Vietnamese
  cy: Welsh
`
}
exports.bahasa = bahasa
